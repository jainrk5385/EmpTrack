package com.example.acer.oets.fragment;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.acer.oets.R;
import com.example.acer.oets.activity.HomeActivity;
import com.example.acer.oets.activity.LoginActivity;
import com.example.acer.oets.utility.Cofig;
import com.example.acer.oets.utility.EmpTrack;
import com.example.acer.oets.utility.SharedPrefData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.thefinestartist.utils.content.ContextUtil.getApplicationContext;


public class changepassword extends Fragment {

    private EditText oldPassword,newPassword,confirmPassword;
    private AppCompatButton changepassword;
    Context thiscontext;
    public static ProgressDialog pDialog;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        thiscontext = inflater.getContext();
        return inflater.inflate(R.layout.fragment_changepassword, container, false);




    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        getAllViews(view);

        pDialog = new ProgressDialog(thiscontext);
        pDialog.setCancelable(false);

        changepassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                oldPassword.setError(null);
                newPassword.setError(null);
                confirmPassword.setError(null);

                String oldPwd = oldPassword.getText().toString().trim();
                String newPwd = newPassword.getText().toString().trim();
                String confirmPwd = confirmPassword.getText().toString().trim();
                View focusView = null;

                if (TextUtils.isEmpty(oldPwd)) {
                    oldPassword.setError("Required !");
                    focusView = oldPassword;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(newPwd)) {
                    newPassword.setError("Required !");
                    focusView = newPassword;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(confirmPwd)) {
                    confirmPassword.setError("Required !");
                    focusView = confirmPassword;
                    focusView.requestFocus();
                    return;
                }


                if(!newPwd.equals(confirmPwd))
                {
                    confirmPassword.setError("Password Not Matched");
                    focusView = confirmPassword;
                    focusView.requestFocus();
                    return;
                }

                changePasswordOnServer(oldPwd,newPwd);

            }
        });
    }

    private void changePasswordOnServer(final String oldPwd, final String newPwd) {

        pDialog.setMessage("Processing. Please Wait...");
        showDialog();

        RequestQueue mRequestQueue = Volley.newRequestQueue(thiscontext);

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.CHANGE_PASSWORD, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {

                hideDialog();


                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);

                        Log.d("param",response1);
                        Log.e("param",response1);


                        String Success= response.getString("Status");
                        String Response = response.getString("Response");

                        if(Success.equalsIgnoreCase("true"))
                        {

                            Toast.makeText(getApplicationContext(), Response, 5000).show();

                            oldPassword.setText("");
                            newPassword.setText("");
                            confirmPassword.setText("");
                        }
                        else
                        {

                            Toast.makeText(getApplicationContext(),Response,2000).show();
                        }







                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;

                if (networkResponse != null) {


                    EmpTrack.showPromptDialog(getActivity(),"Network Error","Please Check your internet connectivity !","Ok",2);

                }

                if (error instanceof TimeoutError) {

                    EmpTrack.showPromptDialog(getActivity(),"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof NoConnectionError)
                    EmpTrack.showPromptDialog(getActivity(), "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                else if (error instanceof AuthFailureError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ServerError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof NetworkError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ParseError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                }





            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("EMPId", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_LOGINID));
                params.put("OldPassword", oldPwd);
                params.put("NewPassword", newPwd);
                params.put("ConfirmPassword", newPwd);


                Log.d("param",String.valueOf(params));
                Log.e("param",String.valueOf(params));
                return params;
            }

        };



        int socketTimeout = 60000;//30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        strReq.setRetryPolicy(policy);
        mRequestQueue.add(strReq);

    }



    public  void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public  void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    private void getAllViews(View view) {

        oldPassword = (EditText) view.findViewById(R.id.oldPassword);
        newPassword = (EditText) view.findViewById(R.id.newPassword);
        confirmPassword = (EditText) view.findViewById(R.id.confirmPassword);
        changepassword = (AppCompatButton) view.findViewById(R.id.changepassword);


    }

}
