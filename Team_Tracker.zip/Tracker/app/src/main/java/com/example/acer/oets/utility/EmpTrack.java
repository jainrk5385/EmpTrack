package com.example.acer.oets.utility;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Build;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;


import com.example.acer.oets.model.UpdateFragmentModel;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.StandardExceptionParser;
import com.google.android.gms.analytics.Tracker;

import java.io.File;
import java.net.NetworkInterface;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cn.refactor.lib.colordialog.PromptDialog;


public class EmpTrack extends Application {

    public static List<UpdateFragmentModel> updateFragmentModelList;
    private final static long MILLISECS_PER_DAY = 24 * 60 * 60 * 1000;
    public static final String TAG = Application.class.getSimpleName();



    private RequestQueue mRequestQueue;
    private static EmpTrack mInstance;
    public static Context MY_APP_CONTEXT = null;
    public static String MY_APP_SHARED_PREFERENCES = "online_xm";
    public static SharedPreferences mPreferences;




    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
        }

    @Override
    public void onCreate() {
        super.onCreate();

        setMyappContext(getApplicationContext());
        updateFragmentModelList = new ArrayList<UpdateFragmentModel>();
        mInstance = this;


        AnalyticsTrackers.initialize(this);
        AnalyticsTrackers.getInstance().get(AnalyticsTrackers.Target.APP);






    }



    public synchronized Tracker getGoogleAnalyticsTracker() {
        AnalyticsTrackers analyticsTrackers = AnalyticsTrackers.getInstance();
        return analyticsTrackers.get(AnalyticsTrackers.Target.APP);
    }

    /***
     * Tracking screen view
     *
     * @param screenName screen name to be displayed on GA dashboard
     */
    public void trackScreenView(String screenName) {
        Tracker t = getGoogleAnalyticsTracker();

        // Set screen name.
        t.setScreenName(screenName);

        // Send a screen view.
        t.send(new HitBuilders.ScreenViewBuilder().build());

        GoogleAnalytics.getInstance(this).dispatchLocalHits();
    }

    /***
     * Tracking exception
     *
     * @param e exception to be tracked
     */
    public void trackException(Exception e) {
        if (e != null) {
            Tracker t = getGoogleAnalyticsTracker();

            t.send(new HitBuilders.ExceptionBuilder()
                    .setDescription(
                            new StandardExceptionParser(this, null)
                                    .getDescription(Thread.currentThread().getName(), e))
                    .setFatal(false)
                    .build()
            );
        }
    }

    /***
     * Tracking event
     *
     * @param category event category
     * @param action   action of the event
     * @param label    label
     */
    public void trackEvent(String category, String action, String label) {
        Tracker t = getGoogleAnalyticsTracker();

        // Build and send an Event.
        t.send(new HitBuilders.EventBuilder().setCategory(category).setAction(action).setLabel(label).build());
    }




    public static Context getMyappContext() {
        return MY_APP_CONTEXT;
    }

    public void setMyappContext(Context mContext) {
        MY_APP_CONTEXT = mContext;
    }


    public static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(MY_APP_SHARED_PREFERENCES, 0);

    }

    public static void writeIntPreference(String key, int value) {
        mPreferences = getSharedPreferences(MY_APP_CONTEXT);
        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putInt(key, value);
        mEditor.commit();

    }
    public static int ReadIntPreferences(String key) {

        mPreferences = getSharedPreferences(MY_APP_CONTEXT);
        return mPreferences.getInt(key, 0);

    }

    public static void writeStringPreference(String key, String value) {
        mPreferences = getSharedPreferences(MY_APP_CONTEXT);
        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.putString(key, value);
        mEditor.commit();

    }

    public static String ReadStringPreferences(String key) {

        mPreferences = getSharedPreferences(MY_APP_CONTEXT);
        return mPreferences.getString(key, "");

    }


    public static void ClearPriferences() {

        mPreferences = getSharedPreferences(MY_APP_CONTEXT);
        SharedPreferences.Editor mEditor = mPreferences.edit();
        mEditor.clear();
        mEditor.commit();
    }


   public static synchronized EmpTrack getInstance() {
        return mInstance;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }

    public <T> void addToRequestQueue(Request<T> req) {
        req.setTag(TAG);
        getRequestQueue().add(req);
    }

    public void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }


    public static String getDate(){

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        return dateFormat.format(date);

    }


    public static void logout_clean_data() {

        String FILE_PATH = "/sdcard/Android/data/com.example.acer.oets/";

        File dir = new File(FILE_PATH);
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                new File(dir, children[i]).delete();
            }
        }

    }

    public static String getTime(){

        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);

    }




    public static int getSignedDiffInDays(Date beginDate, Date endDate) {
        long beginMS = getDateToLong(beginDate);
        long endMS = getDateToLong(endDate);
        long diff = (endMS - beginMS) / (MILLISECS_PER_DAY);
        return (int)diff;
    }

    private static long getDateToLong(Date date) {
        return Date.UTC(date.getYear(), date.getMonth(), date.getDate(), 0, 0, 0);
    }



    public static void showPromptDialog(final Activity activity, String title, String message, String buttonString, int promptType)
    {

       if(!activity.isFinishing())
       {

           new PromptDialog(activity)
                   .setDialogType(promptType)
                   .setAnimationEnable(true)
                   .setTitleText(title)
                   .setContentText(message)
                   .setPositiveListener(buttonString, new PromptDialog.OnPositiveListener() {
                       @Override
                       public void onClick(PromptDialog dialog) {
                           dialog.dismiss();
                       }
                   }).show();

       }

    }




    public static int getAllNotificationsCount(Context mContext){

        int total = 0;

        Database database = new Database(mContext);
        SQLiteDatabase sqLiteDatabase = null;

        try {

            sqLiteDatabase = database.getWritableDatabase();
            String query="select * from pushnotifications";
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);
            total =  cursor.getCount();


        }catch (SQLiteException e)
        {
            e.printStackTrace();
        }finally {
            if (sqLiteDatabase.isOpen()){

                sqLiteDatabase.close();
            }
        }

        return total;
    }


    public static int getAllUnreadNotificationsCount(Context mContext){

        int total = 0;

        Database database = new Database(mContext);
        SQLiteDatabase sqLiteDatabase = null;

        try {

            sqLiteDatabase = database.getWritableDatabase();
            String query="select * from pushnotifications where push_read = 0";
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);
            total =  cursor.getCount();


        }catch (SQLiteException e)
        {

            e.printStackTrace();
        }finally {
            if (sqLiteDatabase.isOpen()){

                sqLiteDatabase.close();
            }
        }

       return total;
    }



    public static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }


    private static String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }



    public static String getMacAddr() {
        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;

                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return "";
                }

                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(String.format("%02X:",b));
                }

                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }


                return res1.toString();


            }

        } catch (Exception ex) {
        }

        return "02:00:00:00:00:00";
    }
    public static boolean validateLetters(String txt) {

        String regx = "[a-zA-Z]+\\.?";
        Pattern pattern = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(txt);
        return matcher.find();

    }

}
