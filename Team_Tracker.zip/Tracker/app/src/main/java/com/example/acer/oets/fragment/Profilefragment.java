package com.example.acer.oets.fragment;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.acer.oets.R;
import com.example.acer.oets.utility.Cofig;
import com.example.acer.oets.utility.EmpTrack;
import com.example.acer.oets.utility.SharedPrefData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by recon on 12/29/2016.
 */

public class Profilefragment extends Fragment {


    Context thiscontext;
    public static ProgressDialog pDialog;
    EditText name,mobile,email,dob,address,city,state,pincode,bank_name,accountno,ifscode;

    public Profilefragment() {
        // Required empty public constructor




    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        thiscontext = inflater.getContext();
        return inflater.inflate(R.layout.fragment_profile, container, false);




    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        getAllViews(view);

        pDialog = new ProgressDialog(thiscontext);
        pDialog.setCancelable(false);




        getData();
    }


    private void getData()
    {
        pDialog.setMessage("Processing. Please Wait...");
        showDialog();

        RequestQueue mRequestQueue = Volley.newRequestQueue(thiscontext);

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.GET_DATA, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {

                hideDialog();


                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);


                        String empID= response.getString("id");
                        String rmpUniqueID = response.getString("EMP_id");

                        String UserID = response.getString("UserID");
                        String FirstName = response.getString("FirstName");

                        String LastName = response.getString("LastName");
                        String Email = response.getString("Email");

                        String Mobile = response.getString("Mobile");
                        String Designation = response.getString("Designation");

                        String DOB = response.getString("DOB");
                        String EMP_Address = response.getString("EMP_Address");


                        email.setText(Email);
                        name.setText(FirstName+" "+LastName);
                        mobile.setText(Mobile);
                        dob.setText(DOB);
                        address.setText(EMP_Address);

                        city.setText("");
                        state.setText("");
                        pincode.setText("");
                        bank_name.setText("");
                        ifscode.setText("");
                        accountno.setText("");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;

                if (networkResponse != null) {


                    EmpTrack.showPromptDialog(getActivity(),"Network Error","Please Check your internet connectivity !","Ok",2);

                }

                if (error instanceof TimeoutError) {

                    EmpTrack.showPromptDialog(getActivity(),"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof NoConnectionError) {

                    EmpTrack.showPromptDialog(getActivity(),"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof AuthFailureError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ServerError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof NetworkError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ParseError) {

                    EmpTrack.showPromptDialog(getActivity(),"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                }





            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("Empid", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_LOGINID));

                Log.d("param",String.valueOf(params));
                Log.e("param",String.valueOf(params));
                return params;
            }

        };



        int socketTimeout = 60000;//30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        strReq.setRetryPolicy(policy);
        mRequestQueue.add(strReq);








    }


    public  void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public  void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    private void getAllViews(View view) {


        name = (EditText) view.findViewById(R.id.name);
        mobile = (EditText) view.findViewById(R.id.mobile);
        email = (EditText) view.findViewById(R.id.email);
        dob = (EditText) view.findViewById(R.id.dob);

        address = (EditText) view.findViewById(R.id.address);
        city = (EditText) view.findViewById(R.id.city);
        state = (EditText) view.findViewById(R.id.state);
        pincode = (EditText) view.findViewById(R.id.pincode);

        bank_name = (EditText) view.findViewById(R.id.bank_name);
        accountno = (EditText) view.findViewById(R.id.accountno);
        ifscode = (EditText) view.findViewById(R.id.ifscode);

    }
}