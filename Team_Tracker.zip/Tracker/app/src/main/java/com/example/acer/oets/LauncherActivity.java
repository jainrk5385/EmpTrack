package com.example.acer.oets;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;

import com.example.acer.oets.activity.HomeActivity;
import com.example.acer.oets.activity.LoginActivity;
import com.example.acer.oets.utility.ConnectionDetector;
import com.example.acer.oets.utility.EmpTrack;
import com.example.acer.oets.utility.SharedPrefData;


public class LauncherActivity extends AppCompatActivity

{
    private ConnectionDetector connectionDetector;
    ActionBar act;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_launcher);


        act = getSupportActionBar();
        act.hide();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (EmpTrack.ReadIntPreferences(SharedPrefData.PREF_ISLOGGEDIN) == 1) {


                    Intent intent = new Intent(LauncherActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(LauncherActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }

            }
        }, 3 * 1000);

    }


}


