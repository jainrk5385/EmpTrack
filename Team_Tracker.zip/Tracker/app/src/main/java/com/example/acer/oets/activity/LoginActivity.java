package com.example.acer.oets.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.acer.oets.R;
import com.example.acer.oets.utility.Cofig;
import com.example.acer.oets.utility.EmpTrack;
import com.example.acer.oets.utility.SharedPrefData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    TextView lblnewuser,lblgrgt;
    Button btnlogin;
    ActionBar act;

    public static ProgressDialog pDialog;
    EditText myEmail, myPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        act=getSupportActionBar();
        act.hide();

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);


        getid();
        lblnewuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intt= new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(intt);
                finish();
            }
        });
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                myEmail.setError(null);
                myPassword.setError(null);

                String stringmyEmail = myEmail.getText().toString().trim();
                String stringmyPassword = myPassword.getText().toString().trim();


                boolean cancel = false;
                View focusView = null;


                if (stringmyEmail.isEmpty()) {
                    myEmail.setError("Enter Email Id");
                    myEmail.requestFocus();
                    return;
                }


                // Check for a valid password, if the user entered one.
                if (TextUtils.isEmpty(stringmyPassword)) {
                    myPassword.setError("Password is Empty");
                    focusView = myPassword;
                    focusView.requestFocus();
                    return;
                }


                login(stringmyEmail, stringmyPassword);



            }
        });
        lblgrgt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intt = new Intent(getApplication(),ForgotPassword.class);
                startActivity(intt);
            }
        });

    }


    private void login(final String userId, final String stringmyPassword) {
        pDialog.setMessage("LogIn. Please Wait...");
        showDialog();

        RequestQueue mRequestQueue = Volley.newRequestQueue(getApplicationContext());

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.USER_LOGIN, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {

                hideDialog();


                Log.d("kkkkk",response1);
                Log.e("kkkkk",response1);

                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);

                        String Success= response.getString("Status");
                        String Response = response.getString("Response");

                        String userEmail = response.getString("EmailId");
                        String userName = response.getString("Name");


                        if(Success.equalsIgnoreCase("true"))
                        {
                            EmpTrack.writeStringPreference(SharedPrefData.PREF_LOGINID, Response);
                            EmpTrack.writeStringPreference(SharedPrefData.PREF_LOGINNAME, userName);
                            EmpTrack.writeStringPreference(SharedPrefData.PREF_LOGINEMAIL, userEmail);
                            EmpTrack.writeIntPreference(SharedPrefData.PREF_ISLOGGEDIN, 1);

                            Toast.makeText(getApplicationContext(), "Login Successfully !", 5000).show();

                            Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        }
                        else
                        {
                            EmpTrack.writeIntPreference(SharedPrefData.PREF_ISLOGGEDIN, 0);

                            Toast.makeText(getApplicationContext(),Response,2000).show();
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;

                if (networkResponse != null) {


                    EmpTrack.showPromptDialog(LoginActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);

                }

                if (error instanceof TimeoutError) {

                    EmpTrack.showPromptDialog(LoginActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                } else if (error instanceof NoConnectionError) {

                    EmpTrack.showPromptDialog(LoginActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                } else if (error instanceof AuthFailureError) {

                    EmpTrack.showPromptDialog(LoginActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                } else if (error instanceof ServerError) {

                    EmpTrack.showPromptDialog(LoginActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                } else if (error instanceof NetworkError) {

                    EmpTrack.showPromptDialog(LoginActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                } else if (error instanceof ParseError) {

                    EmpTrack.showPromptDialog(LoginActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                }


            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();


                params.put("user", userId);
                params.put("password", stringmyPassword);
                params.put("MObDeviceID", String.valueOf(Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID)));

                Log.d("param", String.valueOf(params));
                Log.e("param", String.valueOf(params));
                return params;
            }

        };


        int socketTimeout = 60000;//30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        strReq.setRetryPolicy(policy);
        mRequestQueue.add(strReq);



    }


    public void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }


    public  void getid()
    {
        lblnewuser= (TextView) findViewById(R.id.lblnew);
        btnlogin = (Button) findViewById(R.id.btnlogin);
        lblgrgt= (TextView) findViewById(R.id.lblfrgt);

        myEmail = (EditText) findViewById(R.id.myEmail);
        myPassword = (EditText) findViewById(R.id.myPassword);

    }
}
