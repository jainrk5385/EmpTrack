package com.example.acer.oets.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.acer.oets.R;
import com.example.acer.oets.utility.Cofig;
import com.example.acer.oets.utility.EmpTrack;
import com.example.acer.oets.utility.SharedPrefData;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ForgotPassword extends AppCompatActivity {


    LinearLayout requestCode,verifyCode,changePas;
    EditText myEmail,receviedCode,newPassword,confirmPassword;
    Button requestCodeButton,verifyCodeButton,resendCodeButton,chngePwdButton;
    public static ProgressDialog pDialog;
    TextView sentTv,changPwdTv;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);




        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);








        getAllViews();


        updateStaus();





        requestCodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                myEmail.setError(null);

                String stringmyEmail = myEmail.getText().toString().trim();


                if (!isEmailVerified(stringmyEmail)) {
                    myEmail.setError("Enter Valid Email Address");
                    myEmail.requestFocus();
                    return;
                }




                requestCodeOnServer(stringmyEmail);




            }
        });


        verifyCodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                receviedCode.setError(null);

                String stringmyEmail = receviedCode.getText().toString().trim();


                if (stringmyEmail.isEmpty()) {
                    receviedCode.setError("Enter Valid code !");
                    receviedCode.requestFocus();
                    return;
                }




                verifyCodeOnServer(stringmyEmail);



            }
        });



        resendCodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EmpTrack.writeStringPreference(SharedPrefData.PREF_FORGOTPASSWORDEMAIL,"");
                EmpTrack.writeIntPreference(SharedPrefData.PREF_FORGOTPASSWORDCURRENTSTATUS,0);

                updateStaus();


            }
        });




        chngePwdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                newPassword.setError(null);
                confirmPassword.setError(null);


                String newPwd = newPassword.getText().toString().trim();
                String confirmPwd = confirmPassword.getText().toString().trim();
                View focusView = null;



                if (TextUtils.isEmpty(newPwd)) {
                    newPassword.setError("Required !");
                    focusView = newPassword;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(confirmPwd)) {
                    confirmPassword.setError("Required !");
                    focusView = confirmPassword;
                    focusView.requestFocus();
                    return;
                }


                if(!newPwd.equals(confirmPwd))
                {
                    confirmPassword.setError("Password Not Matched");
                    focusView = confirmPassword;
                    focusView.requestFocus();
                    return;
                }

                changePasswordOnServer(newPwd);




            }
        });










    }

    private void changePasswordOnServer(final String newPwd) {


        pDialog.setMessage("Please Wait...");
        showDialog();


        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.USER_CHANGECODEFORGOT, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {
                hideDialog();

                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);
                        parseJsonFeed(response);
                        String Success= response.getString("Status");
                        String Response = response.getString("Response");

                        if(Success.equalsIgnoreCase("true"))
                        {
                            Toast.makeText(getApplicationContext(), Response, 5000).show();

                        }
                        else
                        {
                            EmpTrack.writeIntPreference(SharedPrefData.PREF_ISLOGGEDIN, 0);

                            Toast.makeText(getApplicationContext(),Response,2000).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;
                if (networkResponse != null) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);

                }

                if (error instanceof TimeoutError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof NoConnectionError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof AuthFailureError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ServerError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof NetworkError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ParseError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                }


            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("email", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_FORGOTPASSWORDEMAIL));
                params.put("password", newPwd);
                params.put("device_id", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_DEVICEID));
                params.put("token_id", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_FCMTOKENID));

                return params;
            }

        };

        EmpTrack.getInstance().addToRequestQueue(strReq, "loginUser");

    }

    private void verifyCodeOnServer(final String stringmyEmail) {


        pDialog.setMessage("Verifying ! Please Wait...");
        showDialog();


        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.USER_VERIFYCODEFORGOT, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {
                hideDialog();

                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);

                        String Success  =response.getString("Success");


                        if(Success.equalsIgnoreCase("true"))
                        {


                            EmpTrack.writeIntPreference(SharedPrefData.PREF_FORGOTPASSWORDCURRENTSTATUS,2);

                            updateStaus();



                        }
                        else
                        {
                            Toast.makeText(ForgotPassword.this,"Please try after sometime !",5000).show();
                        }








                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;
                if (networkResponse != null) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);

                }

                if (error instanceof TimeoutError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof NoConnectionError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof AuthFailureError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ServerError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof NetworkError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ParseError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                }


            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                params.put("email", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_FORGOTPASSWORDEMAIL));
                params.put("code", stringmyEmail);

                return params;
            }

        };

        EmpTrack.getInstance().addToRequestQueue(strReq, "requestCode");

    }

    private void requestCodeOnServer(final String stringmyEmail) {


        pDialog.setMessage("Please Wait...");
        showDialog();


        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.USER_REQUESTCODEFORGOT, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {
                hideDialog();



                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);

                        String Success  =response.getString("Success");


                        if(Success.equalsIgnoreCase("true"))
                        {

                            EmpTrack.writeStringPreference(SharedPrefData.PREF_FORGOTPASSWORDEMAIL,stringmyEmail);
                            EmpTrack.writeIntPreference(SharedPrefData.PREF_FORGOTPASSWORDCURRENTSTATUS,1);

                           updateStaus();




                        }
                        else
                        {
                            Toast.makeText(ForgotPassword.this,"Please try after sometime !",5000).show();
                        }








                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;
                if (networkResponse != null) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);

                }

                if (error instanceof TimeoutError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof NoConnectionError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Network Error","Please Check your internet connectivity !","Ok",2);
                } else if (error instanceof AuthFailureError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ServerError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof NetworkError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                } else if (error instanceof ParseError) {
                    EmpTrack.showPromptDialog(ForgotPassword.this,"Error","AuthFailureError. Please Contact to Admin !","Ok",2);
                }


            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                params.put("email", stringmyEmail);

                return params;
            }

        };

        EmpTrack.getInstance().addToRequestQueue(strReq, "requestCode");

    }

    private void updateStaus() {


        if(EmpTrack.ReadIntPreferences(SharedPrefData.PREF_FORGOTPASSWORDCURRENTSTATUS)==0)
        {

            requestCode.setVisibility(View.VISIBLE);
            verifyCode.setVisibility(View.GONE);
            changePas.setVisibility(View.GONE);

        }
        else if(EmpTrack.ReadIntPreferences(SharedPrefData.PREF_FORGOTPASSWORDCURRENTSTATUS)==1)
        {
            requestCode.setVisibility(View.GONE);
            verifyCode.setVisibility(View.VISIBLE);
            changePas.setVisibility(View.GONE);

        }
        else if(EmpTrack.ReadIntPreferences(SharedPrefData.PREF_FORGOTPASSWORDCURRENTSTATUS)==2)
        {

            requestCode.setVisibility(View.GONE);
            verifyCode.setVisibility(View.GONE);
            changePas.setVisibility(View.VISIBLE);
        }





    }


    private boolean isEmailVerified(String stringmyEmail) {


        return !TextUtils.isEmpty(stringmyEmail) && android.util.Patterns.EMAIL_ADDRESS.matcher(stringmyEmail).matches();

    }

    private void getAllViews() {


        requestCode = (LinearLayout) findViewById(R.id.requestCode);
        verifyCode = (LinearLayout) findViewById(R.id.verifyCode);
        changePas = (LinearLayout) findViewById(R.id.changePas);


        myEmail = (EditText) findViewById(R.id.myEmail);
        receviedCode = (EditText) findViewById(R.id.receviedCode);
        newPassword = (EditText) findViewById(R.id.newPassword);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);


        requestCodeButton = (Button) findViewById(R.id.requestCodeButton);
        verifyCodeButton = (Button) findViewById(R.id.verifyCodeButton);
        resendCodeButton = (Button) findViewById(R.id.resendCodeButton);
        chngePwdButton = (Button) findViewById(R.id.chngePwdButton);

        sentTv = (TextView) findViewById(R.id.sentTv);
        changPwdTv = (TextView) findViewById(R.id.changPwdTv);




    }


    public void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }


    private void parseJsonFeed(JSONObject response) {


        try {

            String Success = response.getString("Success");
            String Message = response.getString("Message");



        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}
