package com.example.acer.oets.utility;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class Database extends SQLiteOpenHelper {



    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "onlinexm";


    // Table Names
    private static final String TABLE_PUSH_NOTIFICATIONSALERTS = "pushnotifications";



    // Table Names
    private static final String TABLE_BOOKMARKED = "bookmarks";





    // TABLE_LOGIN_DETAILS column names
    private static final String KEY_IDPUSH = "id";
    private static final String KEY_PUSHTYPE = "push_type";
    private static final String KEY_PUSHDATA = "push_data";
    private static final String KEY_PUSHISREAD = "push_read";




    // TABLE_LOGIN_DETAILS column names
    private static final String KEY_IDBOOK = "id";
    private static final String KEY_BOOKTYPE = "book_type";
    private static final String KEY_BOOKID = "book_id";
    private static final String KEY_BOOKDATA = "book_data";







    // Todo table create blocked
    private static final String TABLE_BOOKMARKED_CREATE = "CREATE TABLE "
            + TABLE_BOOKMARKED + "(" + KEY_IDBOOK + " INTEGER PRIMARY KEY," + KEY_BOOKTYPE
            + " TEXT," + KEY_BOOKID
            + " TEXT," + KEY_BOOKDATA + " TEXT"
            + ")";



    // Todo table create blocked
    private static final String DATABASE_CREATE_PUSHNOTIFICATIONS = "CREATE TABLE "
            + TABLE_PUSH_NOTIFICATIONSALERTS + "(" + KEY_IDPUSH + " INTEGER PRIMARY KEY," + KEY_PUSHTYPE
            + " TEXT,"+ KEY_PUSHDATA
            + " TEXT," + KEY_PUSHISREAD + " TEXT"
            + ")";



    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(DATABASE_CREATE_PUSHNOTIFICATIONS);

        db.execSQL(TABLE_BOOKMARKED_CREATE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_CREATE_PUSHNOTIFICATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKMARKED_CREATE);
        onCreate(db);

    }
}
