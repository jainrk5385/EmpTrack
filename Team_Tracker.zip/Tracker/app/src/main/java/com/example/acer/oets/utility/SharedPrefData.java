package com.example.acer.oets.utility;



public class SharedPrefData {

    public static String PREF_FCMTOKENID = "fcm_tocken";
    public static String PREF_LOGINID = "lId";
    public static String PREF_ISLOGGEDIN = "is_logged_in";
    public static String PREF_LOGINNAME = "lName";
    public static String PREF_LOGINEMAIL = "lEmail";
    public static String PREF_DEVICEID = "device_id";
    public static String PREF_FORGOTPASSWORDEMAIL = "forgot_pwd_email";
    public static String PREF_FORGOTPASSWORDCURRENTSTATUS = "forgot_pwd_current_status";

}
