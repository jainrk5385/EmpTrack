package com.example.acer.oets.activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.acer.oets.R;
import com.example.acer.oets.utility.Cofig;
import com.example.acer.oets.utility.EmpTrack;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    TextView bklogin;
    Button btnsignup;
    EditText input_firstname, input_lastname, input_email, input_mobile,
            input_desg, input_adddress, input_empid, input_password,
            input_confirmpass;
    ImageView imageView;
    private EditText fromDateEtxt;
    private DatePickerDialog fromDatePickerDialog;
    private SimpleDateFormat dateFormatter;
    private Bitmap currentImage;
    private ImageView selectedImage;
    public static ProgressDialog pDialog;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        findViewsById();
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        bklogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intt = new Intent(getApplication(), LoginActivity.class);
                startActivity(intt);
            }
        });
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                input_firstname.setError(null);
                input_lastname.setError(null);
                input_email.setError(null);
                input_mobile.setError(null);
                input_desg.setError(null);

                input_adddress.setError(null);
                input_empid.setError(null);
                input_password.setError(null);
                input_confirmpass.setError(null);
                fromDateEtxt.setError(null);


                String stringmyFName = input_firstname.getText().toString().trim();
                String stringmyLName = input_lastname.getText().toString().trim();
                String stringmyEmail = input_email.getText().toString().trim();
                String stringmyPhoneNumber = input_mobile.getText().toString().trim();
                String stringmyDesignation = input_desg.getText().toString().trim();

                String stringAddress = input_adddress.getText().toString().trim();
                String stringEmpId = input_empid.getText().toString().trim();
                String stringPassword = input_password.getText().toString().trim();
                String stringConfirmPass = input_confirmpass.getText().toString().trim();
                String stringDob = fromDateEtxt.getText().toString().trim();



                boolean cancel = false;
                View focusView = null;


                String nameMatches = "[a-zA-Z 0-9]+";


                if (TextUtils.isEmpty(stringmyFName)) {
                    input_firstname.setError("Please Type Your First Name");
                    focusView = input_firstname;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(stringmyLName)) {
                    input_lastname.setError("Please Correct Your Last Name");
                    focusView = input_lastname;
                    focusView.requestFocus();
                    return;
                }

                if (!isEmailVerified(stringmyEmail)) {
                    input_email.setError("Enter Valid Email Address");
                    focusView = input_email;
                    focusView.requestFocus();
                    return;
                }

                if (!isPhoneNumberValid(stringmyPhoneNumber)) {
                    input_mobile.setError("Enter Valid Phone Number");
                    focusView = input_mobile;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(stringmyDesignation)) {
                    input_desg.setError("Please Enter Your Designation");
                    focusView = input_desg;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(stringDob)) {
                    fromDateEtxt.setError("Please Select Your DOB");
                    focusView = fromDateEtxt;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(stringAddress)) {
                    input_adddress.setError("Please Enter Your Address");
                    focusView = input_adddress;
                    focusView.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(stringEmpId)) {
                    input_empid.setError("Please Enter Your Employee Id");
                    focusView = input_empid;
                    focusView.requestFocus();
                    return;
                }


                if (TextUtils.isEmpty(stringPassword)) {
                    input_password.setError("Password is Empty");
                    focusView = input_password;
                    focusView.requestFocus();
                    return;
                } else {

                    if (TextUtils.isEmpty(stringConfirmPass)) {
                        input_confirmpass.setError("Retype Password is Empty");
                        focusView = input_confirmpass;
                        focusView.requestFocus();
                        return;
                    } else {


                        if (!stringPassword.equalsIgnoreCase(stringConfirmPass)) {
                            input_confirmpass.setError("Password Not Matched");
                            focusView = input_confirmpass;
                            focusView.requestFocus();
                            return;
                        }

                    }


                }

                userRegister(stringmyFName,stringmyLName,stringmyEmail,stringmyPhoneNumber,stringmyDesignation,
                        stringAddress,stringEmpId,stringPassword,stringConfirmPass,stringDob);

            }
        });


        setDateTimeField();
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent photopickerIntent = new Intent(Intent.ACTION_PICK);
                photopickerIntent.setType("image/*");
                startActivityForResult(photopickerIntent, 1);
            }
        });

    }

    private void userRegister(final String stringmyFName, final String stringmyLName, final String stringmyEmail, final String stringmyPhoneNumber, String stringmyDesignation, String stringAddress, final String stringEmpId, final String stringPassword, final String stringConfirmPass, String stringDob) {


        pDialog.setMessage("Processing. Please Wait...");
        showDialog();

        RequestQueue mRequestQueue = Volley.newRequestQueue(getApplicationContext());

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Cofig.USER_REGISTER, new Response.Listener<String>() {

            @Override
            public void onResponse(String response1) {

                hideDialog();


                Log.d("kkkkk",response1);
                Log.e("kkkkk",response1);

                if (response1 != null) {

                    JSONObject response = null;
                    try {
                        response = new JSONObject(response1);

                        String Success= response.getString("Status");
                        String Response = response.getString("Response");


                        if(Success.equalsIgnoreCase("true"))
                        {
                            Toast.makeText(getApplicationContext(), Response, 5000).show();

                            Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                            startActivity(intent);
                            finish();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),Response,2000).show();
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                hideDialog();


                NetworkResponse networkResponse = error.networkResponse;

                if (networkResponse != null) {


                    EmpTrack.showPromptDialog(RegisterActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);

                }

                if (error instanceof TimeoutError) {

                    EmpTrack.showPromptDialog(RegisterActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                } else if (error instanceof NoConnectionError) {

                    EmpTrack.showPromptDialog(RegisterActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                } else if (error instanceof AuthFailureError) {

                    EmpTrack.showPromptDialog(RegisterActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                } else if (error instanceof ServerError) {

                    EmpTrack.showPromptDialog(RegisterActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                } else if (error instanceof NetworkError) {

                    EmpTrack.showPromptDialog(RegisterActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                } else if (error instanceof ParseError) {

                    EmpTrack.showPromptDialog(RegisterActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                }


            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("FirstName", stringmyFName);
                params.put("LastName", stringmyLName);
                params.put("Email", stringmyEmail);
                params.put("Mobile", stringmyPhoneNumber);
                params.put("EMP_id", stringEmpId);
                params.put("DeviceID", String.valueOf(Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID)));
                params.put("password", stringPassword);

                Log.d("param", String.valueOf(params));
                Log.e("param", String.valueOf(params));
                return params;
            }

        };


        int socketTimeout = 60000;//30 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        strReq.setRetryPolicy(policy);
        mRequestQueue.add(strReq);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_OK) {
            Uri photoUri = data.getData();
            if (photoUri != null) {
                try {
                    currentImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), photoUri);
                    selectedImage.setImageBitmap(currentImage);
                    imageView.setImageBitmap(currentImage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public  void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public  void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    private void findViewsById() {
        fromDateEtxt = (EditText) findViewById(R.id.etxt_fromdate);
        fromDateEtxt.setInputType(InputType.TYPE_NULL);
        fromDateEtxt.requestFocus();
        bklogin = (TextView) findViewById(R.id.bklogin);
        imageView = (ImageView) findViewById(R.id.imgpro);
        btnsignup = (Button) findViewById(R.id.btnsubmit);

        input_firstname = (EditText) findViewById(R.id.input_firstname);
        input_lastname = (EditText) findViewById(R.id.input_lastname);
        input_email = (EditText) findViewById(R.id.input_email);
        input_mobile = (EditText) findViewById(R.id.input_mobile);


        input_desg = (EditText) findViewById(R.id.input_desg);
        input_adddress = (EditText) findViewById(R.id.input_adddress);
        input_empid = (EditText) findViewById(R.id.input_empid);
        input_password = (EditText) findViewById(R.id.input_password);

        input_confirmpass = (EditText) findViewById(R.id.input_confirmpass);

    }

    private void setDateTimeField() {
        fromDateEtxt.setOnClickListener((View.OnClickListener) this);


        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                fromDateEtxt.setText(dateFormatter.format(newDate.getTime()));
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
    }


    public void onClick(View view) {
        if (view == fromDateEtxt) {
            fromDatePickerDialog.show();
        }
    }

    private boolean isEmailVerified(String stringmyEmail) {

        return !TextUtils.isEmpty(stringmyEmail) && android.util.Patterns.EMAIL_ADDRESS.matcher(stringmyEmail).matches();

    }

    private boolean isPhoneNumberValid(String stringmyPhoneNumber) {

        return !TextUtils.isEmpty(stringmyPhoneNumber) && (stringmyPhoneNumber.length() == 10 || stringmyPhoneNumber.length() == 11);


    }
}


