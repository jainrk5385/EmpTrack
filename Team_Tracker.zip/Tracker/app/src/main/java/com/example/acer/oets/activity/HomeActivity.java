package com.example.acer.oets.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.acer.oets.LauncherActivity;
import com.example.acer.oets.fragment.Profilefragment;
import com.example.acer.oets.R;
import com.example.acer.oets.fragment.changepassword;
import com.example.acer.oets.fragment.dashboard;
import com.example.acer.oets.fragment.meetings;
import com.example.acer.oets.utility.Cofig;
import com.example.acer.oets.utility.Database;
import com.example.acer.oets.utility.EmpTrack;
import com.example.acer.oets.utility.SharedPrefData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import cn.refactor.lib.colordialog.PromptDialog;

import static com.example.acer.oets.utility.EmpTrack.logout_clean_data;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    TextView userName, userEmail;
    public static ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header=navigationView.getHeaderView(0);
/*View view=navigationView.inflateHeaderView(R.layout.nav_header_main);*/
        userName = (TextView)header.findViewById(R.id.userName);
        userEmail = (TextView)header.findViewById(R.id.userEmail);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            dashboard fragment = new dashboard();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.container, fragment).commit();
        }


        if (EmpTrack.ReadIntPreferences(SharedPrefData.PREF_ISLOGGEDIN) == 1) {


            userName.setText(EmpTrack.ReadStringPreferences(SharedPrefData.PREF_LOGINNAME));
            userEmail.setText(EmpTrack.ReadStringPreferences(SharedPrefData.PREF_LOGINEMAIL));
        } else {
            userName.setText("Hello User");
            userEmail.setText("test@gmail.com");
        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            new PromptDialog(HomeActivity.this)
                    .setDialogType(PromptDialog.DIALOG_TYPE_WARNING)
                    .setAnimationEnable(true)
                    .setTitleText("Close !")

                    .setContentText("Do you want to Close Emp Track App?")
                    .setPositiveListener("Yes", new PromptDialog.OnPositiveListener() {
                        @Override
                        public void onClick(PromptDialog dialog) {
                            finish();

                        }
                    }).show();

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the HomeActivity/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.home) {
            dashboard fragment = new dashboard();

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            transaction.replace(R.id.container, fragment).commit();


        } else if (id == R.id.profile) {
            Profilefragment fragment = new Profilefragment();

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            transaction.replace(R.id.container, fragment).commit();

        } else if (id == R.id.meeting) {
            meetings fragment = new meetings();

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            transaction.replace(R.id.container, fragment).commit();

        } else if (id == R.id.breaktime) {
            AlertDialog.Builder adb = new AlertDialog.Builder(HomeActivity.this);
            adb.setMessage("Are you sure you want to start your BreakTime Now");
            adb.setCancelable(false);
            adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            adb.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    dialogInterface.dismiss();
                    Toast.makeText(getApplicationContext(), "bye :)", Toast.LENGTH_SHORT).show();
                }
            });
            AlertDialog alert1 = adb.create();
            alert1.show();

        } else if (id == R.id.changepassword) {

            changepassword fragment = new changepassword();

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            transaction.replace(R.id.container, fragment).commit();


        } else if (id == R.id.logout) {

            new PromptDialog(HomeActivity.this)
                    .setDialogType(PromptDialog.DIALOG_TYPE_WARNING)
                    .setAnimationEnable(true)
                    .setTitleText("Logout !")

                    .setContentText("Do you want to logout from Emp Track App?")
                    .setPositiveListener("Yes", new PromptDialog.OnPositiveListener() {
                        @Override
                        public void onClick(final PromptDialog dialog) {


                            pDialog.setMessage("LogIn. Please Wait...");
                            showDialog();

                            RequestQueue mRequestQueue = Volley.newRequestQueue(getApplicationContext());

                            StringRequest strReq = new StringRequest(Request.Method.POST,
                                    Cofig.USER_LOGOUT, new Response.Listener<String>() {

                                @Override
                                public void onResponse(String response1) {

                                    hideDialog();

                                    if (response1 != null) {

                                        JSONObject response = null;
                                        try {
                                            response = new JSONObject(response1);

                                            String Success= response.getString("Status");
                                            String Response = response.getString("Response");

                                            if(Success.equalsIgnoreCase("true"))
                                            {
                                                EmpTrack.writeStringPreference(SharedPrefData.PREF_LOGINID, "");
                                                logout_clean_data();
                                                Database database = new Database(HomeActivity.this);
                                                SQLiteDatabase sqLiteDatabase = null;

                                                try {

                                                    sqLiteDatabase = database.getWritableDatabase();
                                                    sqLiteDatabase.execSQL("delete from pushnotifications");

                                                    String fcmToken = EmpTrack.ReadStringPreferences(SharedPrefData.PREF_FCMTOKENID);
                                                    EmpTrack.ClearPriferences();
                                                    EmpTrack.writeStringPreference(SharedPrefData.PREF_FCMTOKENID, fcmToken);

                                                    Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                    startActivity(intent);

                                                    dialog.dismiss();

                                                } catch (SQLiteException e) {
                                                    e.printStackTrace();
                                                } finally {
                                                    if (sqLiteDatabase.isOpen()) {
                                                        sqLiteDatabase.close();
                                                    }

                                                }
                                            }
                                            else
                                            {
                                                EmpTrack.writeIntPreference(SharedPrefData.PREF_ISLOGGEDIN, 0);

                                                Toast.makeText(getApplicationContext(),Response,2000).show();
                                            }


                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }


                                    }

                                }
                            }, new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError error) {


                                    hideDialog();


                                    NetworkResponse networkResponse = error.networkResponse;

                                    if (networkResponse != null) {


                                        EmpTrack.showPromptDialog(HomeActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);

                                    }

                                    if (error instanceof TimeoutError) {

                                        EmpTrack.showPromptDialog(HomeActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                                    } else if (error instanceof NoConnectionError) {

                                        EmpTrack.showPromptDialog(HomeActivity.this, "Network Error", "Please Check your internet connectivity !", "Ok", 2);
                                    } else if (error instanceof AuthFailureError) {

                                        EmpTrack.showPromptDialog(HomeActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                                    } else if (error instanceof ServerError) {

                                        EmpTrack.showPromptDialog(HomeActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                                    } else if (error instanceof NetworkError) {

                                        EmpTrack.showPromptDialog(HomeActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                                    } else if (error instanceof ParseError) {

                                        EmpTrack.showPromptDialog(HomeActivity.this, "Error", "AuthFailureError. Please Contact to Admin !", "Ok", 2);
                                    }


                                }
                            }) {

                                @Override
                                protected Map<String, String> getParams() {

                                    Map<String, String> params = new HashMap<String, String>();


                                    params.put("EMP", EmpTrack.ReadStringPreferences(SharedPrefData.PREF_LOGINID));

                                    Log.d("param", String.valueOf(params));
                                    Log.e("param", String.valueOf(params));
                                    return params;
                                }

                            };


                            int socketTimeout = 60000;//30 seconds - change to what you want
                            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
                            strReq.setRetryPolicy(policy);
                            mRequestQueue.add(strReq);


//                            EmpTrack.writeStringPreference(SharedPrefData.PREF_LOGINID, "");
//                            logout_clean_data();
//                            Database database = new Database(HomeActivity.this);
//                            SQLiteDatabase sqLiteDatabase = null;
//
//                            try {
//
//                                sqLiteDatabase = database.getWritableDatabase();
//                                sqLiteDatabase.execSQL("delete from pushnotifications");
//
//                                String fcmToken = EmpTrack.ReadStringPreferences(SharedPrefData.PREF_FCMTOKENID);
//                                EmpTrack.ClearPriferences();
//                                EmpTrack.writeStringPreference(SharedPrefData.PREF_FCMTOKENID, fcmToken);
//
//                                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
//                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
//                                        | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                                startActivity(intent);
//                                dialog.dismiss();
//
//
//                            } catch (SQLiteException e) {
//                                e.printStackTrace();
//                            } finally {
//                                if (sqLiteDatabase.isOpen()) {
//                                    sqLiteDatabase.close();
//                                }
//
//                            }

                        }
                    }).show();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}
