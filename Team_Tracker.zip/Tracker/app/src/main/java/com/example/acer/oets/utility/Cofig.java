package com.example.acer.oets.utility;



public class Cofig {

    //---------------------------Test_Series------------------------------------------
    public static String IGURUJI = "http://rishshri1-001-site1.etempurl.com/api/";



    public static String USER_REQUESTCODEFORGOT = IGURUJI+"forgetpassword"; // get data
    public static String USER_VERIFYCODEFORGOT = IGURUJI+"verifyforgetpassword"; // get data
    public static String USER_CHANGECODEFORGOT = IGURUJI+"changepassword"; // get data

    public static String GET_DATA = IGURUJI + "GetData";
    public static String USER_LOGIN = IGURUJI + "GetLogin";

    public static String USER_LOGOUT = IGURUJI + "Logout";

    public static String CHANGE_PASSWORD = IGURUJI + "ChangePassword";

    public static String USER_REGISTER = IGURUJI + "SetRegistration"; // get data


}


